import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RowWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListBody(
        children: [
          Container(
            width: 200,
            child: TextFormField(),
            padding: EdgeInsets.fromLTRB((5), 5, 5, 0),

          )
        ],
      ),
    );
  }
}
