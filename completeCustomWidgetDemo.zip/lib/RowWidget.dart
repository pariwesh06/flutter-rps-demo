import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RowWidget extends StatelessWidget {
  doSomething() {}
  @override
  Widget build(BuildContext context) {
    return ListBody(
      children: [
        Row(
          children: [
            Container(
              width: 200,
              child: TextFormField(
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              padding: EdgeInsets.fromLTRB((5), 5, 5, 0),
            ),
            Container(
              width: 30,
              child: Checkbox(
                onChanged: doSomething(),
                value: true,
              ),
              padding: EdgeInsets.fromLTRB((5), 5, 5, 0),
            ),
          ],
        )
      ],
    );
  }
}
