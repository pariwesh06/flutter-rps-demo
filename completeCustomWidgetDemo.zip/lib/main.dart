import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'RowWidget.dart';

void main(List<String> args) {
  runApp(Home());
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dynamic Widget',
      home: HomePage(),
      theme: ThemeData(primarySwatch: Colors.blue),
    );
  }
}

class HomePage extends StatefulWidget {
  HomePage({Key key}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {
  List<RowWidget> list = [];
  addRow() {
    list.add(RowWidget());
    setState(() {
      
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(child: ListView(children: list)),
      floatingActionButton:
          FloatingActionButton(onPressed: addRow, child: Icon(Icons.add)),
    ); //RowWidget();
  }
  //technical Debt
}
